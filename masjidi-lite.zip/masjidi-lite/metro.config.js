// Learn more: https://docs.expo.dev/guides/customizing-metro
const { getDefaultConfig } = require('expo/metro-config');
const config = getDefaultConfig(__dirname);
// Ensure audio asset extensions are bundled
const extra = ['mp3', 'wav', 'ogg', 'm4a', 'aac'];
extra.forEach((e) => {
  if (!config.resolver.assetExts.includes(e)) config.resolver.assetExts.push(e);
});
module.exports = config;
