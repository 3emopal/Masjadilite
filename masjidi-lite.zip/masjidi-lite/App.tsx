import React, { useCallback, useEffect } from 'react';
import { View, I18nManager, AppState, StyleSheet } from 'react-native';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import * as Notifications from 'expo-notifications';
import {
  useFonts,
  Cairo_400Regular,
  Cairo_600SemiBold,
  Cairo_700Bold,
} from '@expo-google-fonts/cairo';
import { Amiri_400Regular, Amiri_700Bold } from '@expo-google-fonts/amiri';

import { colors } from './src/theme/colors';
import { fonts } from './src/theme/fonts';
import PrayerScreen from './src/screens/PrayerScreen';
import ImsakiahScreen from './src/screens/ImsakiahScreen';
import TasbeehScreen from './src/screens/TasbeehScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import { useSettings } from './src/store/settings';
import { applyNotificationSchedule } from './src/utils/scheduleFromSettings';
import { setupChannels } from './src/utils/notifications';

// نُبقي اتجاه التخطيط LTR ونتحكم بالـ RTL يدوياً عبر الأنماط (row-reverse / textAlign).
// هذا يتجنّب الحاجة لإعادة تشغيل التطبيق ويجعل التصميم متوقّعاً على كل الأجهزة.
I18nManager.allowRTL(false);
I18nManager.forceRTL(false);

SplashScreen.preventAutoHideAsync().catch(() => {});

const Tab = createBottomTabNavigator();

const navTheme = {
  ...DefaultTheme,
  colors: { ...DefaultTheme.colors, background: colors.bg, card: colors.bgDeep, border: colors.line },
};

const TAB_ICONS: Record<string, { on: keyof typeof Ionicons.glyphMap; off: keyof typeof Ionicons.glyphMap }> = {
  المواقيت: { on: 'time', off: 'time-outline' },
  الإمساكية: { on: 'calendar', off: 'calendar-outline' },
  المسبحة: { on: 'ellipse', off: 'ellipse-outline' },
  الإعدادات: { on: 'settings', off: 'settings-outline' },
};

export default function App() {
  const hydrated = useSettings((s) => s.hydrated);

  const [fontsLoaded] = useFonts({
    Cairo_400Regular,
    Cairo_600SemiBold,
    Cairo_700Bold,
    Amiri_400Regular,
    Amiri_700Bold,
  });

  // إعداد القنوات + جدولة أولية بعد ترطيب الإعدادات
  useEffect(() => {
    if (!hydrated) return;
    (async () => {
      await setupChannels();
      const { status } = await Notifications.getPermissionsAsync();
      if (status === 'granted') await applyNotificationSchedule();
    })();
  }, [hydrated]);

  // جدّد الجدولة كلما عاد التطبيق للمقدمة أو وصل إشعار (لتقديم النافذة الزمنية)
  useEffect(() => {
    if (!hydrated) return;
    const appSub = AppState.addEventListener('change', async (s) => {
      if (s === 'active') {
        const { status } = await Notifications.getPermissionsAsync();
        if (status === 'granted') await applyNotificationSchedule();
      }
    });
    const notifSub = Notifications.addNotificationReceivedListener(async () => {
      const { status } = await Notifications.getPermissionsAsync();
      if (status === 'granted') await applyNotificationSchedule();
    });
    return () => {
      appSub.remove();
      notifSub.remove();
    };
  }, [hydrated]);

  const onLayoutRootView = useCallback(async () => {
    if (fontsLoaded && hydrated) await SplashScreen.hideAsync().catch(() => {});
  }, [fontsLoaded, hydrated]);

  if (!fontsLoaded || !hydrated) return null;

  return (
    <SafeAreaProvider>
      <View style={styles.root} onLayout={onLayoutRootView}>
        <StatusBar style="light" />
        <NavigationContainer theme={navTheme}>
          <Tab.Navigator
            screenOptions={({ route }) => ({
              headerShown: false,
              tabBarActiveTintColor: colors.gold,
              tabBarInactiveTintColor: colors.textMutedOnDark,
              tabBarStyle: {
                backgroundColor: colors.bgDeep,
                borderTopColor: colors.line,
                height: 62,
                paddingBottom: 8,
                paddingTop: 6,
              },
              tabBarLabelStyle: { fontFamily: fonts.medium, fontSize: 12 },
              tabBarIcon: ({ focused, color, size }) => {
                const ic = TAB_ICONS[route.name] || TAB_ICONS['المواقيت'];
                return <Ionicons name={focused ? ic.on : ic.off} size={size} color={color} />;
              },
            })}
          >
            <Tab.Screen name="المواقيت" component={PrayerScreen} />
            <Tab.Screen name="الإمساكية" component={ImsakiahScreen} />
            <Tab.Screen name="المسبحة" component={TasbeehScreen} />
            <Tab.Screen name="الإعدادات" component={SettingsScreen} />
          </Tab.Navigator>
        </NavigationContainer>
      </View>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
});
