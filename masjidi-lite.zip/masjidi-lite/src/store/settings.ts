import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { PrayerKey } from '../data/imsakiah';
import type { FajrBasis } from '../utils/prayer';
import type { ReciterId } from '../utils/audio';

interface SettingsState {
  hydrated: boolean;
  enabledPrayers: Record<PrayerKey, boolean>;
  reminderMinutes: number; // 0 = بدون
  fajrBasis: FajrBasis;
  reciter: ReciterId;
  playAdhanInApp: boolean; // تشغيل الأذان كاملاً داخل التطبيق عند فتحه وقت الصلاة
  vibrate: boolean;

  togglePrayer: (k: PrayerKey) => void;
  setReminder: (m: number) => void;
  setFajrBasis: (b: FajrBasis) => void;
  setReciter: (r: ReciterId) => void;
  setPlayAdhanInApp: (v: boolean) => void;
  setVibrate: (v: boolean) => void;
  _setHydrated: () => void;
}

export const useSettings = create<SettingsState>()(
  persist(
    (set) => ({
      hydrated: false,
      enabledPrayers: {
        fajr: true,
        sunrise: false, // الشروق ليس صلاة
        dhuhr: true,
        asr: true,
        maghrib: true,
        isha: true,
      },
      reminderMinutes: 0,
      fajrBasis: 'second',
      reciter: 'adhan1',
      playAdhanInApp: true,
      vibrate: true,

      togglePrayer: (k) =>
        set((s) => ({ enabledPrayers: { ...s.enabledPrayers, [k]: !s.enabledPrayers[k] } })),
      setReminder: (m) => set({ reminderMinutes: m }),
      setFajrBasis: (b) => set({ fajrBasis: b }),
      setReciter: (r) => set({ reciter: r }),
      setPlayAdhanInApp: (v) => set({ playAdhanInApp: v }),
      setVibrate: (v) => set({ vibrate: v }),
      _setHydrated: () => set({ hydrated: true }),
    }),
    {
      name: 'settings-v1',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (s) => ({
        enabledPrayers: s.enabledPrayers,
        reminderMinutes: s.reminderMinutes,
        fajrBasis: s.fajrBasis,
        reciter: s.reciter,
        playAdhanInApp: s.playAdhanInApp,
        vibrate: s.vibrate,
      }),
      onRehydrateStorage: () => (state) => {
        state?._setHydrated();
      },
    }
  )
);
