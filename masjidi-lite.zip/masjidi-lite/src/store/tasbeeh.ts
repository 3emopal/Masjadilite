import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { localDateKey } from '../utils/time';

export interface Dhikr {
  id: string;
  text: string; // العربية
  translit?: string;
  defaultTarget: number;
}

export const DHIKR_PRESETS: Dhikr[] = [
  { id: 'subhan', text: 'سُبْحَانَ اللَّه', defaultTarget: 33 },
  { id: 'hamd', text: 'الْحَمْدُ لِلَّه', defaultTarget: 33 },
  { id: 'akbar', text: 'اللَّهُ أَكْبَر', defaultTarget: 34 },
  { id: 'tahlil', text: 'لَا إِلَٰهَ إِلَّا اللَّه', defaultTarget: 100 },
  { id: 'hawqala', text: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّه', defaultTarget: 100 },
  { id: 'istighfar', text: 'أَسْتَغْفِرُ اللَّه', defaultTarget: 100 },
  { id: 'salah', text: 'اللَّهُمَّ صَلِّ عَلَى مُحَمَّد', defaultTarget: 100 },
];

interface TasbeehState {
  hydrated: boolean;
  dhikrId: string;
  count: number; // العدّاد الحالي (الدورة)
  target: number;
  laps: number; // كم مرة اكتمل الهدف في الجلسة
  todayKey: string;
  todayTotal: number; // إجمالي اليوم
  grandTotal: number; // الإجمالي الكلي

  increment: () => { reachedTarget: boolean };
  reset: () => void;
  setDhikr: (id: string) => void;
  setTarget: (t: number) => void;
  _rollDay: () => void;
  _setHydrated: () => void;
}

export const useTasbeeh = create<TasbeehState>()(
  persist(
    (set, get) => ({
      hydrated: false,
      dhikrId: 'subhan',
      count: 0,
      target: 33,
      laps: 0,
      todayKey: localDateKey(),
      todayTotal: 0,
      grandTotal: 0,

      increment: () => {
        const s = get();
        const next = s.count + 1;
        const reached = next >= s.target;
        set({
          count: reached ? 0 : next,
          laps: reached ? s.laps + 1 : s.laps,
          todayTotal: s.todayTotal + 1,
          grandTotal: s.grandTotal + 1,
        });
        return { reachedTarget: reached };
      },

      reset: () => set({ count: 0, laps: 0 }),

      setDhikr: (id) => {
        const d = DHIKR_PRESETS.find((x) => x.id === id);
        set({ dhikrId: id, count: 0, laps: 0, target: d ? d.defaultTarget : get().target });
      },

      setTarget: (t) => set({ target: Math.max(1, t), count: 0, laps: 0 }),

      _rollDay: () => {
        const today = localDateKey();
        if (get().todayKey !== today) set({ todayKey: today, todayTotal: 0 });
      },

      _setHydrated: () => {
        set({ hydrated: true });
        get()._rollDay();
      },
    }),
    {
      name: 'tasbeeh-v1',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (s) => ({
        dhikrId: s.dhikrId,
        count: s.count,
        target: s.target,
        laps: s.laps,
        todayKey: s.todayKey,
        todayTotal: s.todayTotal,
        grandTotal: s.grandTotal,
      }),
      onRehydrateStorage: () => (state) => {
        state?._setHydrated();
      },
    }
  )
);
