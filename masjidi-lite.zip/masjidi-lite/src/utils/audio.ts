import { Audio, AVPlaybackStatus } from 'expo-av';

// خريطة المؤذنين — ملفات محلية (require ثابت مطلوب في RN).
// الأسماء استُخرجت من أسماء ملفات المصدر وقد تحتاج تدقيقاً؛ بدّلها كما تشاء.
export const RECITERS = {
  adhan1: { id: 'adhan1', name: 'أذان — تلاوة ١', file: require('../../assets/audio/adhan1.mp3') },
  adhan2: { id: 'adhan2', name: 'أذان — تلاوة ٢', file: require('../../assets/audio/adhan2.mp3') },
  adhan3: { id: 'adhan3', name: 'أذان — تلاوة ٣', file: require('../../assets/audio/adhan3.mp3') },
} as const;

export type ReciterId = keyof typeof RECITERS;
export const RECITER_LIST = Object.values(RECITERS);

const IQAMA = require('../../assets/audio/iqama.mp3');

let current: Audio.Sound | null = null;
let onDoneCb: (() => void) | null = null;

async function ensureMode() {
  await Audio.setAudioModeAsync({
    playsInSilentModeIOS: true,
    staysActiveInBackground: false,
    shouldDuckAndroid: true,
    playThroughEarpieceAndroid: false,
  });
}

async function unload() {
  if (current) {
    try {
      await current.stopAsync();
    } catch {}
    try {
      await current.unloadAsync();
    } catch {}
    current = null;
  }
}

/** يشغّل أذان المؤذن المختار داخل التطبيق. */
export async function playAdhan(reciter: ReciterId, onDone?: () => void) {
  await ensureMode();
  await unload();
  onDoneCb = onDone || null;
  const { sound } = await Audio.Sound.createAsync(RECITERS[reciter].file, {
    shouldPlay: true,
    volume: 1.0,
  });
  current = sound;
  sound.setOnPlaybackStatusUpdate((status: AVPlaybackStatus) => {
    if (status.isLoaded && status.didJustFinish) {
      onDoneCb?.();
      unload();
    }
  });
}

export async function playIqama(onDone?: () => void) {
  await ensureMode();
  await unload();
  onDoneCb = onDone || null;
  const { sound } = await Audio.Sound.createAsync(IQAMA, { shouldPlay: true, volume: 1.0 });
  current = sound;
  sound.setOnPlaybackStatusUpdate((status: AVPlaybackStatus) => {
    if (status.isLoaded && status.didJustFinish) {
      onDoneCb?.();
      unload();
    }
  });
}

export async function stopAudio() {
  onDoneCb = null;
  await unload();
}

export function isPlaying(): boolean {
  return current !== null;
}
