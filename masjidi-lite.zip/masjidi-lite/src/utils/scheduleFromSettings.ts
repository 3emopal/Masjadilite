import { useSettings } from '../store/settings';
import { rescheduleAll, setupChannels, requestPermission } from './notifications';

/**
 * يقرأ الإعدادات الحالية ويعيد جدولة كل الإشعارات.
 * يُستدعى عند الإقلاع وعند أي تغيير في إعدادات الإشعارات.
 */
export async function applyNotificationSchedule(): Promise<number> {
  const s = useSettings.getState();
  await setupChannels();
  return rescheduleAll({
    enabledPrayers: s.enabledPrayers,
    reminderMinutes: s.reminderMinutes,
    fajrBasis: s.fajrBasis,
  });
}

/** يطلب الإذن ثم يجدول. يُرجع عدد الإشعارات المجدولة (أو -1 إذا رُفض الإذن). */
export async function enableAndSchedule(): Promise<number> {
  const granted = await requestPermission();
  if (!granted) return -1;
  return applyNotificationSchedule();
}
