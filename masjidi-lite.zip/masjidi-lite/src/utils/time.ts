// أدوات الوقت — كلها بالتوقيت المحلي للجهاز (يُفترض Asia/Gaza).

/** مفتاح التاريخ المحلي "YYYY-MM-DD" (وليس UTC). */
export function localDateKey(d: Date = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

/** يبني كائن Date محلي من تاريخ "YYYY-MM-DD" ووقت "HH:mm". */
export function dateAt(dateStr: string, hhmm: string): Date {
  const [y, m, d] = dateStr.split('-').map(Number);
  const [hh, mm] = hhmm.split(':').map(Number);
  return new Date(y, m - 1, d, hh, mm, 0, 0);
}

/** يوم غد كـ "YYYY-MM-DD". */
export function nextDateKey(dateStr: string): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(y, m - 1, d + 1);
  return localDateKey(dt);
}

const AR_DIGITS = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
export function toArabicDigits(s: string | number): string {
  return String(s).replace(/[0-9]/g, (d) => AR_DIGITS[+d]);
}

/** "16:28" -> "٤:٢٨ م" (12 ساعة بالعربي). */
export function formatTime12(hhmm: string, arabic = true): string {
  const [hh, mm] = hhmm.split(':').map(Number);
  const period = hh >= 12 ? 'م' : 'ص';
  let h12 = hh % 12;
  if (h12 === 0) h12 = 12;
  const t = `${h12}:${String(mm).padStart(2, '0')} ${period}`;
  return arabic ? toArabicDigits(t) : t;
}

/** فرق زمني -> "٣ س ٢٥ د ١٠ ث" */
export function formatCountdown(ms: number): string {
  if (ms < 0) ms = 0;
  const total = Math.floor(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const parts: string[] = [];
  if (h > 0) parts.push(`${toArabicDigits(h)} س`);
  parts.push(`${toArabicDigits(m)} د`);
  parts.push(`${toArabicDigits(String(s).padStart(2, '0'))} ث`);
  return parts.join('  ');
}
