import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import { PrayerKey } from '../data/imsakiah';
import { buildPrayerList, PRAYER_LABELS, ADHAN_PRAYERS } from './prayer';
import { localDateKey, nextDateKey, formatTime12 } from './time';
import type { FajrBasis } from './prayer';

// أسماء أصوات القنوات = أسماء ملفات wav المُجمّعة عبر إضافة expo-notifications.
const SOUND_ADHAN = 'adhan_short.wav';
const SOUND_NOTIFY = 'notify.wav';

export const CH_ADHAN = 'adhan-v1';
export const CH_REMINDER = 'reminder-v1';

// كيف يظهر الإشعار عندما يكون التطبيق مفتوحاً
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export async function requestPermission(): Promise<boolean> {
  if (!Device.isDevice) return false;
  const { status: existing } = await Notifications.getPermissionsAsync();
  let final = existing;
  if (existing !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    final = status;
  }
  return final === 'granted';
}

export async function setupChannels() {
  if (Platform.OS !== 'android') return;
  await Notifications.setNotificationChannelAsync(CH_ADHAN, {
    name: 'الأذان',
    importance: Notifications.AndroidImportance.MAX,
    sound: SOUND_ADHAN,
    vibrationPattern: [0, 400, 200, 400],
    lightColor: '#137C66',
    bypassDnd: false,
    lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
  });
  await Notifications.setNotificationChannelAsync(CH_REMINDER, {
    name: 'تذكير قبل الصلاة',
    importance: Notifications.AndroidImportance.HIGH,
    sound: SOUND_NOTIFY,
    vibrationPattern: [0, 250, 150, 250],
    lightColor: '#D4AF37',
  });
}

export interface ScheduleOptions {
  enabledPrayers: Record<PrayerKey, boolean>; // أي الصلوات مفعّلة
  reminderMinutes: number; // 0 = بدون تذكير مسبق
  fajrBasis: FajrBasis;
  horizonDays?: number; // كم يوماً للأمام نجدول
}

/**
 * يلغي كل الإشعارات ثم يعيد جدولتها لعدد من الأيام القادمة.
 * تُستدعى عند الإقلاع وعند تغيير الإعدادات.
 * ملاحظة: iOS يحدّ الإشعارات المجدولة بـ 64، لذا نقلّص الأفق تلقائياً.
 */
export async function rescheduleAll(opts: ScheduleOptions): Promise<number> {
  await Notifications.cancelAllScheduledNotificationsAsync();

  const withReminder = opts.reminderMinutes > 0;
  // احسب أفقاً آمناً لا يتجاوز 60 إشعاراً تقريباً
  const perDay =
    ADHAN_PRAYERS.filter((p) => opts.enabledPrayers[p]).length * (withReminder ? 2 : 1);
  let horizon = opts.horizonDays ?? (withReminder ? 6 : 12);
  if (perDay > 0) horizon = Math.min(horizon, Math.floor(60 / perDay) || 1);

  const now = new Date();
  let dayKey = localDateKey(now);
  let scheduled = 0;

  for (let i = 0; i < horizon; i++) {
    const list = buildPrayerList(dayKey, opts.fajrBasis).filter((p) => p.isAdhan);
    if (list.length === 0) break; // لا بيانات لهذا اليوم -> توقف

    for (const p of list) {
      if (!opts.enabledPrayers[p.key]) continue;

      // إشعار الأذان في وقت الصلاة
      if (p.date.getTime() > now.getTime()) {
        await Notifications.scheduleNotificationAsync({
          content: {
            title: `حان الآن موعد ${PRAYER_LABELS[p.key]}`,
            body: `${PRAYER_LABELS[p.key]} — قطاع غزة  •  ${formatTime12(p.hhmm)}`,
            sound: SOUND_ADHAN,
            ...(Platform.OS === 'android' ? { channelId: CH_ADHAN } : {}),
          },
          trigger: p.date,
        });
        scheduled++;
      }

      // تذكير قبل الصلاة
      if (withReminder) {
        const remDate = new Date(p.date.getTime() - opts.reminderMinutes * 60000);
        if (remDate.getTime() > now.getTime()) {
          await Notifications.scheduleNotificationAsync({
            content: {
              title: `${PRAYER_LABELS[p.key]} بعد ${opts.reminderMinutes} دقيقة`,
              body: `اقترب موعد ${PRAYER_LABELS[p.key]} (${formatTime12(p.hhmm)})`,
              sound: SOUND_NOTIFY,
              ...(Platform.OS === 'android' ? { channelId: CH_REMINDER } : {}),
            },
            trigger: remDate,
          });
          scheduled++;
        }
      }
    }
    dayKey = nextDateKey(dayKey);
  }
  return scheduled;
}

export async function cancelAll() {
  await Notifications.cancelAllScheduledNotificationsAsync();
}

export async function getScheduledCount(): Promise<number> {
  const list = await Notifications.getAllScheduledNotificationsAsync();
  return list.length;
}
