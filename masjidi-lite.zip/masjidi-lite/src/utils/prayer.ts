import { ALL_DAYS, DayTimes, PrayerKey } from '../data/imsakiah';
import { dateAt, localDateKey, nextDateKey } from './time';

export type FajrBasis = 'second' | 'first'; // الأذان الثاني (افتراضي) أو الأول

export const PRAYER_LABELS: Record<PrayerKey, string> = {
  fajr: 'الفجر',
  sunrise: 'الشروق',
  dhuhr: 'الظهر',
  asr: 'العصر',
  maghrib: 'المغرب',
  isha: 'العشاء',
};

// الصلوات التي يُرفع لها أذان (الشروق ليس صلاة — يُعرض فقط للعلم)
export const ADHAN_PRAYERS: PrayerKey[] = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];

export interface PrayerItem {
  key: PrayerKey;
  label: string;
  hhmm: string; // "HH:mm"
  date: Date; // وقت الصلاة اليوم كـ Date محلي
  isAdhan: boolean; // هل يُرفع له أذان
}

export function getDay(dateStr: string): DayTimes | undefined {
  return ALL_DAYS[dateStr];
}

/** قائمة الأوقات الستة ليوم معيّن، مع مراعاة أساس الفجر. */
export function buildPrayerList(
  dateStr: string,
  fajrBasis: FajrBasis = 'second'
): PrayerItem[] {
  const d = ALL_DAYS[dateStr];
  if (!d) return [];
  const fajrTime = fajrBasis === 'first' ? d.fajrFirst : d.fajr;
  const rows: { key: PrayerKey; hhmm: string }[] = [
    { key: 'fajr', hhmm: fajrTime },
    { key: 'sunrise', hhmm: d.sunrise },
    { key: 'dhuhr', hhmm: d.dhuhr },
    { key: 'asr', hhmm: d.asr },
    { key: 'maghrib', hhmm: d.maghrib },
    { key: 'isha', hhmm: d.isha },
  ];
  return rows.map((r) => ({
    key: r.key,
    label: PRAYER_LABELS[r.key],
    hhmm: r.hhmm,
    date: dateAt(dateStr, r.hhmm),
    isAdhan: ADHAN_PRAYERS.includes(r.key),
  }));
}

export interface NextPrayer {
  item: PrayerItem;
  dayKey: string; // التاريخ الذي تقع فيه
  msRemaining: number;
}

/**
 * تُرجع الصلاة القادمة (تتخطّى الشروق) بحثاً في اليوم الحالي ثم الغد.
 * تعتمد فقط على الأيام المتوفرة في الإمساكية. تُرجع null إذا انتهت البيانات.
 */
export function getNextPrayer(
  now: Date = new Date(),
  fajrBasis: FajrBasis = 'second'
): NextPrayer | null {
  const todayKey = localDateKey(now);
  const candidates: { item: PrayerItem; dayKey: string }[] = [];

  for (const key of [todayKey, nextDateKey(todayKey)]) {
    const list = buildPrayerList(key, fajrBasis).filter((p) => p.isAdhan);
    for (const item of list) candidates.push({ item, dayKey: key });
  }

  for (const c of candidates) {
    if (c.item.date.getTime() > now.getTime()) {
      return {
        item: c.item,
        dayKey: c.dayKey,
        msRemaining: c.item.date.getTime() - now.getTime(),
      };
    }
  }
  return null;
}

/** الصلاة الحالية (آخر صلاة مضت اليوم) — لتظليلها في القائمة. */
export function getCurrentPrayerKey(
  now: Date = new Date(),
  fajrBasis: FajrBasis = 'second'
): PrayerKey | null {
  const todayKey = localDateKey(now);
  const list = buildPrayerList(todayKey, fajrBasis).filter((p) => p.isAdhan);
  let current: PrayerKey | null = null;
  for (const p of list) {
    if (p.date.getTime() <= now.getTime()) current = p.key;
  }
  return current;
}

/** هل لدينا بيانات لتاريخ اليوم؟ */
export function hasDataForToday(now: Date = new Date()): boolean {
  return !!ALL_DAYS[localDateKey(now)];
}
