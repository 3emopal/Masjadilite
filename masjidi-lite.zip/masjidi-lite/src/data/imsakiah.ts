// ============================================================
//  إمساكية غزة — بيانات محلية (تُحدَّث شهرياً)
//  المصدر: إمساكية "هلال غزة" — إعداد مصطفى قشاوي (قطاع غزة/فلسطين)
//  الشهر: صفر 1448هـ  |  15 يوليو – 13 أغسطس 2026م
//  ملاحظة: الفجر الافتراضي = الأذان الثاني (الفجر الصادق).
//          fajrFirst = الأذان الأول (يُستخدم للإمساك) — قابل للتبديل من الإعدادات.
//  لإضافة شهر جديد: انسخ كائن Month جديداً داخل مصفوفة MONTHS بنفس الصيغة.
// ============================================================

export type PrayerKey = "fajr" | "sunrise" | "dhuhr" | "asr" | "maghrib" | "isha";

export interface DayTimes {
  date: string;        // "YYYY-MM-DD" ميلادي
  hijri: number;       // اليوم الهجري داخل الشهر
  weekday: string;     // اليوم بالعربي
  fajrFirst: string;   // "HH:mm" الأذان الأول (إمساك)
  fajr: string;        // "HH:mm" الفجر (الأذان الثاني)
  sunrise: string;     // "HH:mm" الشروق
  dhuhr: string;       // "HH:mm" الظهر
  asr: string;         // "HH:mm" العصر
  maghrib: string;     // "HH:mm" المغرب
  isha: string;        // "HH:mm" العشاء
}

export interface MonthData {
  id: string;
  hijriMonth: string;
  hijriYear: number;
  gregorianLabel: string;
  location: string;
  source: string;
  days: DayTimes[];
}

const safar1448: MonthData = {
  id: "safar-1448",
  hijriMonth: "صفر",
  hijriYear: 1448,
  gregorianLabel: "يوليو – أغسطس 2026",
  location: "قطاع غزة — فلسطين",
  source: "إمساكية هلال غزة — مصطفى قشاوي",
  days: [
  { date: "2026-07-15", hijri: 1, weekday: "الأربعاء", fajrFirst: "03:32", fajr: "04:02", sunrise: "05:48", dhuhr: "12:48", asr: "16:28", maghrib: "19:51", isha: "21:21" },
  { date: "2026-07-16", hijri: 2, weekday: "الخميس", fajrFirst: "03:33", fajr: "04:03", sunrise: "05:49", dhuhr: "12:48", asr: "16:28", maghrib: "19:51", isha: "21:21" },
  { date: "2026-07-17", hijri: 3, weekday: "الجمعة", fajrFirst: "03:34", fajr: "04:04", sunrise: "05:50", dhuhr: "12:48", asr: "16:28", maghrib: "19:50", isha: "21:20" },
  { date: "2026-07-18", hijri: 4, weekday: "السبت", fajrFirst: "03:35", fajr: "04:05", sunrise: "05:50", dhuhr: "12:48", asr: "16:28", maghrib: "19:50", isha: "21:19" },
  { date: "2026-07-19", hijri: 5, weekday: "الأحد", fajrFirst: "03:36", fajr: "04:06", sunrise: "05:51", dhuhr: "12:48", asr: "16:28", maghrib: "19:49", isha: "21:18" },
  { date: "2026-07-20", hijri: 6, weekday: "الاثنين", fajrFirst: "03:37", fajr: "04:07", sunrise: "05:51", dhuhr: "12:48", asr: "16:28", maghrib: "19:49", isha: "21:17" },
  { date: "2026-07-21", hijri: 7, weekday: "الثلاثاء", fajrFirst: "03:38", fajr: "04:08", sunrise: "05:52", dhuhr: "12:48", asr: "16:28", maghrib: "19:48", isha: "21:17" },
  { date: "2026-07-22", hijri: 8, weekday: "الأربعاء", fajrFirst: "03:39", fajr: "04:09", sunrise: "05:53", dhuhr: "12:48", asr: "16:28", maghrib: "19:47", isha: "21:16" },
  { date: "2026-07-23", hijri: 9, weekday: "الخميس", fajrFirst: "03:40", fajr: "04:10", sunrise: "05:53", dhuhr: "12:48", asr: "16:28", maghrib: "19:47", isha: "21:15" },
  { date: "2026-07-24", hijri: 10, weekday: "الجمعة", fajrFirst: "03:41", fajr: "04:11", sunrise: "05:54", dhuhr: "12:48", asr: "16:28", maghrib: "19:46", isha: "21:14" },
  { date: "2026-07-25", hijri: 11, weekday: "السبت", fajrFirst: "03:41", fajr: "04:11", sunrise: "05:55", dhuhr: "12:48", asr: "16:28", maghrib: "19:45", isha: "21:13" },
  { date: "2026-07-26", hijri: 12, weekday: "الأحد", fajrFirst: "03:42", fajr: "04:12", sunrise: "05:55", dhuhr: "12:48", asr: "16:28", maghrib: "19:45", isha: "21:12" },
  { date: "2026-07-27", hijri: 13, weekday: "الاثنين", fajrFirst: "03:43", fajr: "04:13", sunrise: "05:56", dhuhr: "12:48", asr: "16:28", maghrib: "19:44", isha: "21:11" },
  { date: "2026-07-28", hijri: 14, weekday: "الثلاثاء", fajrFirst: "03:44", fajr: "04:14", sunrise: "05:57", dhuhr: "12:48", asr: "16:28", maghrib: "19:43", isha: "21:11" },
  { date: "2026-07-29", hijri: 15, weekday: "الأربعاء", fajrFirst: "03:45", fajr: "04:15", sunrise: "05:57", dhuhr: "12:48", asr: "16:28", maghrib: "19:43", isha: "21:10" },
  { date: "2026-07-30", hijri: 16, weekday: "الخميس", fajrFirst: "03:46", fajr: "04:16", sunrise: "05:58", dhuhr: "12:48", asr: "16:28", maghrib: "19:42", isha: "21:09" },
  { date: "2026-07-31", hijri: 17, weekday: "الجمعة", fajrFirst: "03:47", fajr: "04:17", sunrise: "05:58", dhuhr: "12:48", asr: "16:28", maghrib: "19:42", isha: "21:08" },
  { date: "2026-08-01", hijri: 18, weekday: "السبت", fajrFirst: "03:48", fajr: "04:18", sunrise: "05:59", dhuhr: "12:48", asr: "16:28", maghrib: "19:41", isha: "21:07" },
  { date: "2026-08-02", hijri: 19, weekday: "الأحد", fajrFirst: "03:49", fajr: "04:19", sunrise: "06:00", dhuhr: "12:48", asr: "16:28", maghrib: "19:40", isha: "21:06" },
  { date: "2026-08-03", hijri: 20, weekday: "الاثنين", fajrFirst: "03:50", fajr: "04:20", sunrise: "06:00", dhuhr: "12:48", asr: "16:28", maghrib: "19:39", isha: "21:05" },
  { date: "2026-08-04", hijri: 21, weekday: "الثلاثاء", fajrFirst: "03:51", fajr: "04:21", sunrise: "06:01", dhuhr: "12:48", asr: "16:27", maghrib: "19:38", isha: "21:03" },
  { date: "2026-08-05", hijri: 22, weekday: "الأربعاء", fajrFirst: "03:52", fajr: "04:22", sunrise: "06:01", dhuhr: "12:47", asr: "16:27", maghrib: "19:37", isha: "21:02" },
  { date: "2026-08-06", hijri: 23, weekday: "الخميس", fajrFirst: "03:53", fajr: "04:23", sunrise: "06:02", dhuhr: "12:47", asr: "16:27", maghrib: "19:36", isha: "21:01" },
  { date: "2026-08-07", hijri: 24, weekday: "الجمعة", fajrFirst: "03:54", fajr: "04:24", sunrise: "06:03", dhuhr: "12:47", asr: "16:27", maghrib: "19:35", isha: "21:00" },
  { date: "2026-08-08", hijri: 25, weekday: "السبت", fajrFirst: "03:55", fajr: "04:25", sunrise: "06:03", dhuhr: "12:47", asr: "16:27", maghrib: "19:34", isha: "20:59" },
  { date: "2026-08-09", hijri: 26, weekday: "الأحد", fajrFirst: "03:56", fajr: "04:26", sunrise: "06:04", dhuhr: "12:47", asr: "16:26", maghrib: "19:34", isha: "20:57" },
  { date: "2026-08-10", hijri: 27, weekday: "الاثنين", fajrFirst: "03:57", fajr: "04:27", sunrise: "06:04", dhuhr: "12:47", asr: "16:26", maghrib: "19:33", isha: "20:56" },
  { date: "2026-08-11", hijri: 28, weekday: "الثلاثاء", fajrFirst: "03:58", fajr: "04:28", sunrise: "06:05", dhuhr: "12:47", asr: "16:26", maghrib: "19:32", isha: "20:55" },
  { date: "2026-08-12", hijri: 29, weekday: "الأربعاء", fajrFirst: "03:59", fajr: "04:29", sunrise: "06:06", dhuhr: "12:47", asr: "16:26", maghrib: "19:30", isha: "20:54" },
  { date: "2026-08-13", hijri: 30, weekday: "الخميس", fajrFirst: "04:00", fajr: "04:30", sunrise: "06:06", dhuhr: "12:46", asr: "16:26", maghrib: "19:30", isha: "20:53" },
  ],
};

export const MONTHS: MonthData[] = [safar1448];

/** كل الأيام من كل الشهور في مصفوفة واحدة، مفهرسة بالتاريخ الميلادي. */
export const ALL_DAYS: Record<string, DayTimes> = MONTHS.reduce((acc, mo) => {
  mo.days.forEach((d) => (acc[d.date] = d));
  return acc;
}, {} as Record<string, DayTimes>);
