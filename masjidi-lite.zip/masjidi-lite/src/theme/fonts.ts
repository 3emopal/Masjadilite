// أسماء الخطوط كما تُحمّل في App.tsx عبر @expo-google-fonts
export const fonts = {
  regular: 'Cairo_400Regular',
  medium: 'Cairo_600SemiBold',
  bold: 'Cairo_700Bold',
  // خط زخرفي للعناوين والأذكار
  quran: 'Amiri_400Regular',
  quranBold: 'Amiri_700Bold',
};
