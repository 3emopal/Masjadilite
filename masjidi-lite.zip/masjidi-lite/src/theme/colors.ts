export const colors = {
  // خلفيات
  bg: '#0B5647',          // أخضر داكن
  bgDeep: '#083D33',
  surface: '#0F6B57',
  surfaceAlt: '#0D5F4D',
  card: '#FFFFFF',
  cardMuted: '#F3F0E6',

  // نصوص
  text: '#0E2A24',
  textOnDark: '#F5F0E1',
  textMutedOnDark: '#BFE0D5',
  textMuted: '#5B7A72',

  // لمسات
  gold: '#D4AF37',
  goldSoft: '#E7CE7A',
  teal: '#137C66',
  tealLight: '#2E9E86',

  // حالات الصلاة
  next: '#D4AF37',
  passed: '#7FA99E',

  line: '#1E7A66',
  danger: '#C0563B',
  success: '#2E9E86',
  white: '#FFFFFF',
};

export const prayerColors: Record<string, string> = {
  fajr: '#2E9E86',
  sunrise: '#E0A93B',
  dhuhr: '#3AA0C9',
  asr: '#C98A3A',
  maghrib: '#B4633A',
  isha: '#4B5FA6',
};
