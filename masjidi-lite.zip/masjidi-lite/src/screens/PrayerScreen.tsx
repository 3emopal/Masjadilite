import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  AppState,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors, prayerColors } from '../theme/colors';
import { fonts } from '../theme/fonts';
import { MONTHS } from '../data/imsakiah';
import {
  buildPrayerList,
  getNextPrayer,
  getCurrentPrayerKey,
  PRAYER_LABELS,
} from '../utils/prayer';
import { localDateKey, formatTime12, formatCountdown, toArabicDigits } from '../utils/time';
import { useSettings } from '../store/settings';
import { playAdhan, stopAudio, RECITERS } from '../utils/audio';

const PRAYER_ICONS: Record<string, keyof typeof Ionicons.glyphMap> = {
  fajr: 'cloudy-night',
  sunrise: 'partly-sunny',
  dhuhr: 'sunny',
  asr: 'sunny-outline',
  maghrib: 'moon-outline',
  isha: 'moon',
};

function hijriLabelFor(dateStr: string): string {
  for (const mo of MONTHS) {
    const d = mo.days.find((x) => x.date === dateStr);
    if (d) return `${toArabicDigits(d.hijri)} ${mo.hijriMonth} ${toArabicDigits(mo.hijriYear)}هـ`;
  }
  return '';
}

export default function PrayerScreen() {
  const { fajrBasis, reciter, playAdhanInApp, vibrate } = useSettings();
  const [now, setNow] = useState(new Date());
  const [adhanPlaying, setAdhanPlaying] = useState(false);
  const firedRef = useRef<string | null>(null);

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const todayKey = localDateKey(now);
  const todayList = buildPrayerList(todayKey, fajrBasis);
  const currentKey = getCurrentPrayerKey(now, fajrBasis);
  const next = getNextPrayer(now, fajrBasis);
  const hijri = hijriLabelFor(todayKey);
  const todayDay = MONTHS.flatMap((m) => m.days).find((d) => d.date === todayKey);

  // تشغيل الأذان تلقائياً عند لحظة دخول الوقت (بينما التطبيق مفتوح)
  useEffect(() => {
    if (!playAdhanInApp) return;
    const list = buildPrayerList(todayKey, fajrBasis).filter((p) => p.isAdhan);
    for (const p of list) {
      const diff = now.getTime() - p.date.getTime();
      const key = `${todayKey}-${p.key}`;
      // خلال ثانية ونصف بعد وقت الصلاة، ولمرة واحدة فقط
      if (diff >= 0 && diff < 1500 && firedRef.current !== key) {
        firedRef.current = key;
        handlePlay();
        break;
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [now, playAdhanInApp, fajrBasis, todayKey]);

  // أوقف الأذان إذا خرج التطبيق للخلفية (المشغّل داخلي فقط)
  useEffect(() => {
    const sub = AppState.addEventListener('change', (s) => {
      if (s !== 'active') {
        stopAudio();
        setAdhanPlaying(false);
      }
    });
    return () => sub.remove();
  }, []);

  async function handlePlay() {
    setAdhanPlaying(true);
    await playAdhan(reciter, () => setAdhanPlaying(false));
  }
  async function handleStop() {
    await stopAudio();
    setAdhanPlaying(false);
  }

  const noData = todayList.length === 0;

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 28 }}>
        {/* ترويسة */}
        <View style={styles.header}>
          <Text style={styles.appTitle}>مسجدي</Text>
          <Text style={styles.loc}>قطاع غزة — فلسطين</Text>
          {!!todayDay && (
            <Text style={styles.dateLine}>
              {todayDay.weekday}  •  {hijri}
            </Text>
          )}
        </View>

        {noData ? (
          <View style={styles.noData}>
            <Ionicons name="calendar-outline" size={44} color={colors.goldSoft} />
            <Text style={styles.noDataTitle}>لا توجد بيانات لهذا اليوم</Text>
            <Text style={styles.noDataText}>
              انتهت الإمساكية المحمّلة. أضِف الشهر التالي في{'\n'}
              <Text style={styles.mono}>src/data/imsakiah.ts</Text>
            </Text>
          </View>
        ) : (
          <>
            {/* بطاقة الصلاة القادمة */}
            <View style={styles.hero}>
              {next ? (
                <>
                  <Text style={styles.heroLabel}>الصلاة القادمة</Text>
                  <Text style={styles.heroName}>{next.item.label}</Text>
                  <Text style={styles.heroTime}>{formatTime12(next.item.hhmm)}</Text>
                  <View style={styles.countdownBox}>
                    <Ionicons name="time-outline" size={16} color={colors.bgDeep} />
                    <Text style={styles.countdownText}>{formatCountdown(next.msRemaining)}</Text>
                  </View>
                </>
              ) : (
                <Text style={styles.heroName}>—</Text>
              )}
            </View>

            {/* شريط الأذان */}
            {adhanPlaying ? (
              <TouchableOpacity style={styles.adhanBar} onPress={handleStop} activeOpacity={0.85}>
                <Ionicons name="stop-circle" size={22} color={colors.white} />
                <Text style={styles.adhanBarText}>الأذان يُرفع الآن — إيقاف</Text>
              </TouchableOpacity>
            ) : (
              <TouchableOpacity style={styles.testBar} onPress={handlePlay} activeOpacity={0.85}>
                <Ionicons name="play-circle-outline" size={20} color={colors.gold} />
                <Text style={styles.testBarText}>
                  تشغيل الأذان ({RECITERS[reciter].name})
                </Text>
              </TouchableOpacity>
            )}

            {/* قائمة صلوات اليوم */}
            <View style={styles.list}>
              {todayList.map((p) => {
                const isNext = next && next.dayKey === todayKey && next.item.key === p.key;
                const isCurrent = currentKey === p.key;
                const isSunrise = p.key === 'sunrise';
                return (
                  <View
                    key={p.key}
                    style={[
                      styles.row,
                      isNext && styles.rowNext,
                      isCurrent && styles.rowCurrent,
                    ]}
                  >
                    <View style={styles.rowRight}>
                      <View
                        style={[
                          styles.iconWrap,
                          { backgroundColor: (prayerColors[p.key] || colors.teal) + '22' },
                        ]}
                      >
                        <Ionicons
                          name={PRAYER_ICONS[p.key]}
                          size={18}
                          color={prayerColors[p.key] || colors.teal}
                        />
                      </View>
                      <View>
                        <Text style={[styles.rowName, isNext && styles.rowNameNext]}>
                          {p.label}
                          {isSunrise ? '  (شروق)' : ''}
                        </Text>
                        {isNext && <Text style={styles.rowTag}>التالية</Text>}
                        {isCurrent && !isNext && <Text style={styles.rowTagCur}>الحالية</Text>}
                      </View>
                    </View>
                    <Text style={[styles.rowTime, isNext && styles.rowTimeNext]}>
                      {formatTime12(p.hhmm)}
                    </Text>
                  </View>
                );
              })}
            </View>

            {/* الأذان الأول (إمساك) للعلم */}
            {!!todayDay && (
              <Text style={styles.footNote}>
                الأذان الأول (إمساك): {formatTime12(todayDay.fajrFirst)}
              </Text>
            )}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  header: { alignItems: 'center', paddingTop: 10, paddingBottom: 6 },
  appTitle: { fontFamily: fonts.quranBold, fontSize: 34, color: colors.goldSoft },
  loc: { fontFamily: fonts.regular, fontSize: 13, color: colors.textMutedOnDark, marginTop: 2 },
  dateLine: {
    fontFamily: fonts.medium,
    fontSize: 13,
    color: colors.textOnDark,
    marginTop: 6,
    writingDirection: 'rtl',
  },

  hero: {
    backgroundColor: colors.gold,
    marginHorizontal: 16,
    marginTop: 14,
    borderRadius: 22,
    paddingVertical: 22,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 6 },
    elevation: 6,
  },
  heroLabel: { fontFamily: fonts.medium, fontSize: 14, color: colors.bgDeep },
  heroName: { fontFamily: fonts.bold, fontSize: 34, color: colors.bgDeep, marginTop: 2 },
  heroTime: { fontFamily: fonts.bold, fontSize: 22, color: '#5A4A12', marginTop: 2 },
  countdownBox: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#00000018',
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 14,
    marginTop: 12,
  },
  countdownText: { fontFamily: fonts.bold, fontSize: 16, color: colors.bgDeep },

  adhanBar: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: colors.danger,
    marginHorizontal: 16,
    marginTop: 12,
    paddingVertical: 12,
    borderRadius: 14,
  },
  adhanBarText: { fontFamily: fonts.bold, fontSize: 15, color: colors.white },
  testBar: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: colors.surface,
    marginHorizontal: 16,
    marginTop: 12,
    paddingVertical: 12,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.line,
  },
  testBarText: { fontFamily: fonts.medium, fontSize: 14, color: colors.textOnDark },

  list: { marginHorizontal: 16, marginTop: 16, gap: 10 },
  row: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.card,
    borderRadius: 16,
    paddingVertical: 12,
    paddingHorizontal: 14,
  },
  rowNext: { backgroundColor: '#FFF7E0', borderWidth: 1.5, borderColor: colors.gold },
  rowCurrent: { backgroundColor: '#EAF6F1' },
  rowRight: { flexDirection: 'row-reverse', alignItems: 'center', gap: 12 },
  iconWrap: {
    width: 38,
    height: 38,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rowName: { fontFamily: fonts.bold, fontSize: 17, color: colors.text, textAlign: 'right' },
  rowNameNext: { color: '#5A4A12' },
  rowTag: { fontFamily: fonts.medium, fontSize: 11, color: colors.gold, textAlign: 'right' },
  rowTagCur: { fontFamily: fonts.medium, fontSize: 11, color: colors.teal, textAlign: 'right' },
  rowTime: { fontFamily: fonts.bold, fontSize: 16, color: colors.textMuted },
  rowTimeNext: { color: '#5A4A12' },

  footNote: {
    fontFamily: fonts.regular,
    fontSize: 12,
    color: colors.textMutedOnDark,
    textAlign: 'center',
    marginTop: 14,
  },

  noData: { alignItems: 'center', marginTop: 60, paddingHorizontal: 30, gap: 10 },
  noDataTitle: { fontFamily: fonts.bold, fontSize: 18, color: colors.textOnDark },
  noDataText: {
    fontFamily: fonts.regular,
    fontSize: 14,
    color: colors.textMutedOnDark,
    textAlign: 'center',
    lineHeight: 24,
  },
  mono: { fontFamily: fonts.medium, color: colors.goldSoft },
});
