import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Switch, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { fonts } from '../theme/fonts';
import { useSettings } from '../store/settings';
import { PrayerKey } from '../data/imsakiah';
import { PRAYER_LABELS, ADHAN_PRAYERS } from '../utils/prayer';
import { RECITER_LIST } from '../utils/audio';
import { playAdhan, stopAudio } from '../utils/audio';
import { applyNotificationSchedule, enableAndSchedule } from '../utils/scheduleFromSettings';
import { getScheduledCount } from '../utils/notifications';
import { toArabicDigits } from '../utils/time';

const REMINDERS = [0, 5, 10, 15, 20];

export default function SettingsScreen() {
  const s = useSettings();
  const [count, setCount] = useState<number>(0);

  const refreshCount = async () => setCount(await getScheduledCount());
  useEffect(() => {
    refreshCount();
  }, []);

  // إعادة الجدولة عند تغيّر أي إعداد مؤثر
  const affecting = JSON.stringify([s.enabledPrayers, s.reminderMinutes, s.fajrBasis]);
  useEffect(() => {
    if (!s.hydrated) return;
    (async () => {
      await applyNotificationSchedule();
      refreshCount();
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [affecting, s.hydrated]);

  async function onEnable() {
    const n = await enableAndSchedule();
    if (n < 0) {
      Alert.alert('الإشعارات معطّلة', 'فعّل صلاحية الإشعارات من إعدادات النظام لتصلك مواعيد الأذان.');
    } else {
      Alert.alert('تم', `تم جدولة ${toArabicDigits(n)} إشعاراً للأيام القادمة.`);
      refreshCount();
    }
  }

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 32 }}>
        <Text style={styles.title}>الإعدادات</Text>

        {/* الإشعارات */}
        <Section title="الإشعارات والأذان">
          <TouchableOpacity style={styles.enableBtn} onPress={onEnable} activeOpacity={0.85}>
            <Ionicons name="notifications" size={18} color={colors.bgDeep} />
            <Text style={styles.enableTxt}>تفعيل إشعارات الأذان</Text>
          </TouchableOpacity>
          <Text style={styles.hint}>
            مجدول حالياً: {toArabicDigits(count)} إشعاراً. افتح التطبيق بين الحين والآخر لتجديد
            الجدولة تلقائياً.
          </Text>

          {ADHAN_PRAYERS.map((k) => (
            <ToggleRow
              key={k}
              label={`تنبيه ${PRAYER_LABELS[k as PrayerKey]}`}
              value={s.enabledPrayers[k]}
              onValueChange={() => s.togglePrayer(k)}
            />
          ))}
        </Section>

        {/* التذكير المسبق */}
        <Section title="تذكير قبل الصلاة">
          <View style={styles.pillRow}>
            {REMINDERS.map((m) => (
              <TouchableOpacity
                key={m}
                onPress={() => s.setReminder(m)}
                style={[styles.pill, s.reminderMinutes === m && styles.pillActive]}
              >
                <Text style={[styles.pillTxt, s.reminderMinutes === m && styles.pillTxtActive]}>
                  {m === 0 ? 'بدون' : `${toArabicDigits(m)} د`}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </Section>

        {/* أساس الفجر */}
        <Section title="حساب الفجر">
          <View style={styles.pillRow}>
            <TouchableOpacity
              onPress={() => s.setFajrBasis('second')}
              style={[styles.pillWide, s.fajrBasis === 'second' && styles.pillActive]}
            >
              <Text style={[styles.pillTxt, s.fajrBasis === 'second' && styles.pillTxtActive]}>
                الأذان الثاني (الفجر الصادق)
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => s.setFajrBasis('first')}
              style={[styles.pillWide, s.fajrBasis === 'first' && styles.pillActive]}
            >
              <Text style={[styles.pillTxt, s.fajrBasis === 'first' && styles.pillTxtActive]}>
                الأذان الأول (إمساك)
              </Text>
            </TouchableOpacity>
          </View>
        </Section>

        {/* المؤذن */}
        <Section title="صوت الأذان (داخل التطبيق)">
          {RECITER_LIST.map((r) => (
            <TouchableOpacity
              key={r.id}
              style={[styles.reciterRow, s.reciter === r.id && styles.reciterActive]}
              onPress={() => s.setReciter(r.id as any)}
              activeOpacity={0.85}
            >
              <View style={styles.reciterLeft}>
                <TouchableOpacity
                  onPress={async () => {
                    await stopAudio();
                    await playAdhan(r.id as any);
                  }}
                  style={styles.previewBtn}
                >
                  <Ionicons name="play" size={16} color={colors.gold} />
                </TouchableOpacity>
                <Text style={styles.reciterName}>{r.name}</Text>
              </View>
              <Ionicons
                name={s.reciter === r.id ? 'radio-button-on' : 'radio-button-off'}
                size={20}
                color={s.reciter === r.id ? colors.gold : colors.textMutedOnDark}
              />
            </TouchableOpacity>
          ))}
          <ToggleRow
            label="تشغيل الأذان كاملاً داخل التطبيق عند دخول الوقت"
            value={s.playAdhanInApp}
            onValueChange={s.setPlayAdhanInApp}
          />
        </Section>

        {/* المسبحة */}
        <Section title="المسبحة">
          <ToggleRow label="اهتزاز عند التسبيح" value={s.vibrate} onValueChange={s.setVibrate} />
        </Section>

        <Text style={styles.foot}>
          المواقيت محلية من إمساكية غزة — تعمل بدون إنترنت. تُفترض منطقة الجهاز الزمنية Asia/Gaza.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <View style={styles.sectionBody}>{children}</View>
    </View>
  );
}

function ToggleRow({
  label,
  value,
  onValueChange,
}: {
  label: string;
  value: boolean;
  onValueChange: (v: boolean) => void;
}) {
  return (
    <View style={styles.toggleRow}>
      <Text style={styles.toggleLabel}>{label}</Text>
      <Switch
        value={value}
        onValueChange={onValueChange}
        trackColor={{ false: '#3A5C52', true: colors.gold }}
        thumbColor={value ? '#FFF6DA' : '#CBD8D2'}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  title: { fontFamily: fonts.bold, fontSize: 22, color: colors.goldSoft, textAlign: 'center', marginTop: 8, marginBottom: 6 },

  section: { marginHorizontal: 16, marginTop: 18 },
  sectionTitle: { fontFamily: fonts.bold, fontSize: 15, color: colors.textMutedOnDark, marginBottom: 8, textAlign: 'right' },
  sectionBody: { backgroundColor: colors.surface, borderRadius: 16, paddingHorizontal: 14, paddingVertical: 6, borderWidth: 1, borderColor: colors.line },

  enableBtn: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: colors.gold,
    paddingVertical: 12,
    borderRadius: 12,
    marginVertical: 8,
  },
  enableTxt: { fontFamily: fonts.bold, fontSize: 15, color: colors.bgDeep },
  hint: { fontFamily: fonts.regular, fontSize: 12, color: colors.textMutedOnDark, textAlign: 'right', marginBottom: 8, lineHeight: 20 },

  toggleRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.line,
  },
  toggleLabel: { fontFamily: fonts.medium, fontSize: 14, color: colors.textOnDark, flex: 1, textAlign: 'right', marginLeft: 10 },

  pillRow: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 8, paddingVertical: 10 },
  pill: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 12, backgroundColor: colors.surfaceAlt, borderWidth: 1, borderColor: colors.line },
  pillWide: { flexGrow: 1, alignItems: 'center', paddingHorizontal: 12, paddingVertical: 10, borderRadius: 12, backgroundColor: colors.surfaceAlt, borderWidth: 1, borderColor: colors.line },
  pillActive: { backgroundColor: colors.gold, borderColor: colors.gold },
  pillTxt: { fontFamily: fonts.medium, fontSize: 13, color: colors.textOnDark },
  pillTxtActive: { color: colors.bgDeep },

  reciterRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.line,
  },
  reciterActive: {},
  reciterLeft: { flexDirection: 'row-reverse', alignItems: 'center', gap: 12 },
  previewBtn: {
    width: 34,
    height: 34,
    borderRadius: 10,
    backgroundColor: colors.surfaceAlt,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.line,
  },
  reciterName: { fontFamily: fonts.medium, fontSize: 14, color: colors.textOnDark },

  foot: { fontFamily: fonts.regular, fontSize: 12, color: colors.textMutedOnDark, textAlign: 'center', marginTop: 22, marginHorizontal: 20, lineHeight: 20 },
});
