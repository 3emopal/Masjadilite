import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, prayerColors } from '../theme/colors';
import { fonts } from '../theme/fonts';
import { MONTHS, DayTimes } from '../data/imsakiah';
import { useSettings } from '../store/settings';
import { localDateKey, formatTime12, toArabicDigits } from '../utils/time';

const COLS: { key: keyof DayTimes | 'fajr'; label: string; w: number }[] = [
  { key: 'fajr', label: 'الفجر', w: 62 },
  { key: 'sunrise', label: 'الشروق', w: 62 },
  { key: 'dhuhr', label: 'الظهر', w: 62 },
  { key: 'asr', label: 'العصر', w: 62 },
  { key: 'maghrib', label: 'المغرب', w: 62 },
  { key: 'isha', label: 'العشاء', w: 62 },
];
const DATE_W = 96;
const TABLE_W = DATE_W + COLS.reduce((s, c) => s + c.w, 0);

export default function ImsakiahScreen() {
  const { fajrBasis } = useSettings();
  const [monthIdx, setMonthIdx] = useState(0);
  const month = MONTHS[monthIdx];
  const today = localDateKey();

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>الإمساكية الشهرية</Text>
        <View style={styles.switcher}>
          <TouchableOpacity
            disabled={monthIdx <= 0}
            onPress={() => setMonthIdx((i) => Math.max(0, i - 1))}
            style={[styles.navBtn, monthIdx <= 0 && styles.navDisabled]}
          >
            <Text style={styles.navTxt}>‹</Text>
          </TouchableOpacity>
          <View style={styles.monthPill}>
            <Text style={styles.monthName}>
              {month.hijriMonth} {toArabicDigits(month.hijriYear)}هـ
            </Text>
            <Text style={styles.monthGreg}>{month.gregorianLabel}</Text>
          </View>
          <TouchableOpacity
            disabled={monthIdx >= MONTHS.length - 1}
            onPress={() => setMonthIdx((i) => Math.min(MONTHS.length - 1, i + 1))}
            style={[styles.navBtn, monthIdx >= MONTHS.length - 1 && styles.navDisabled]}
          >
            <Text style={styles.navTxt}>›</Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.src}>{month.source}</Text>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        bounces={false}
        style={styles.hscroll}
      >
        <View style={{ width: TABLE_W, height: '100%' }}>
          {/* رأس الجدول */}
          <View style={[styles.trow, styles.thead]}>
            <View style={[styles.cell, { width: DATE_W }]}>
              <Text style={styles.th}>التاريخ</Text>
            </View>
            {COLS.map((c) => (
              <View key={c.key} style={[styles.cell, { width: c.w }]}>
                <Text style={styles.th}>{c.label}</Text>
              </View>
            ))}
          </View>

          <ScrollView
            style={{ flex: 1 }}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ paddingBottom: 24 }}
          >
            {month.days.map((d, i) => {
              const isToday = d.date === today;
              const gd = d.date.slice(8); // DD
              const gm = Number(d.date.slice(5, 7));
              const gmName = gm === 7 ? 'يوليو' : gm === 8 ? 'أغسطس' : `${gm}`;
              const fajr = fajrBasis === 'first' ? d.fajrFirst : d.fajr;
              return (
                <View
                  key={d.date}
                  style={[
                    styles.trow,
                    i % 2 === 1 && styles.trowAlt,
                    isToday && styles.trowToday,
                  ]}
                >
                  <View style={[styles.cell, styles.dateCell, { width: DATE_W }]}>
                    <Text style={[styles.hijriNum, isToday && styles.todayTxt]}>
                      {toArabicDigits(d.hijri)}
                    </Text>
                    <View>
                      <Text style={[styles.weekday, isToday && styles.todayTxt]}>{d.weekday}</Text>
                      <Text style={styles.greg}>
                        {toArabicDigits(gd)} {gmName}
                      </Text>
                    </View>
                  </View>
                  {[fajr, d.sunrise, d.dhuhr, d.asr, d.maghrib, d.isha].map((t, ci) => (
                    <View key={ci} style={[styles.cell, { width: COLS[ci].w }]}>
                      <Text
                        style={[
                          styles.tval,
                          isToday && styles.todayTxt,
                          { color: isToday ? colors.bgDeep : colors.text },
                        ]}
                      >
                        {formatTime12(t)}
                      </Text>
                    </View>
                  ))}
                </View>
              );
            })}
          </ScrollView>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  header: { paddingHorizontal: 16, paddingTop: 8, paddingBottom: 10, alignItems: 'center' },
  title: { fontFamily: fonts.bold, fontSize: 20, color: colors.goldSoft },
  switcher: { flexDirection: 'row-reverse', alignItems: 'center', gap: 12, marginTop: 10 },
  navBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.line,
  },
  navDisabled: { opacity: 0.35 },
  navTxt: { color: colors.goldSoft, fontSize: 24, fontFamily: fonts.bold, marginTop: -4 },
  monthPill: { alignItems: 'center', minWidth: 150 },
  monthName: { fontFamily: fonts.bold, fontSize: 18, color: colors.textOnDark },
  monthGreg: { fontFamily: fonts.regular, fontSize: 12, color: colors.textMutedOnDark },
  src: { fontFamily: fonts.regular, fontSize: 11, color: colors.textMutedOnDark, marginTop: 8 },
  hscroll: { flex: 1 },

  trow: { flexDirection: 'row-reverse', alignItems: 'stretch', backgroundColor: colors.card },
  trowAlt: { backgroundColor: '#F6F3EA' },
  trowToday: { backgroundColor: colors.goldSoft },
  thead: { backgroundColor: colors.bgDeep, borderTopLeftRadius: 12, borderTopRightRadius: 12 },
  cell: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 9,
    borderColor: '#00000010',
    borderRightWidth: StyleSheet.hairlineWidth,
  },
  dateCell: { flexDirection: 'row-reverse', gap: 8, paddingHorizontal: 8, justifyContent: 'flex-start' },
  th: { fontFamily: fonts.bold, fontSize: 13, color: colors.goldSoft },
  hijriNum: { fontFamily: fonts.bold, fontSize: 18, color: colors.teal, width: 22, textAlign: 'center' },
  weekday: { fontFamily: fonts.medium, fontSize: 12, color: colors.text, textAlign: 'right' },
  greg: { fontFamily: fonts.regular, fontSize: 10, color: colors.textMuted, textAlign: 'right' },
  tval: { fontFamily: fonts.medium, fontSize: 12.5, color: colors.text },
  todayTxt: { color: colors.bgDeep, fontFamily: fonts.bold },
});
