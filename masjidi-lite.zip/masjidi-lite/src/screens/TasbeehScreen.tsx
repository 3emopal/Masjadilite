import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { fonts } from '../theme/fonts';
import { useTasbeeh, DHIKR_PRESETS } from '../store/tasbeeh';
import { useSettings } from '../store/settings';
import { toArabicDigits } from '../utils/time';

const TARGETS = [33, 99, 100, 1000];

export default function TasbeehScreen() {
  const {
    dhikrId,
    count,
    target,
    laps,
    todayTotal,
    grandTotal,
    increment,
    reset,
    setDhikr,
    setTarget,
  } = useTasbeeh();
  const { vibrate } = useSettings();

  const dhikr = DHIKR_PRESETS.find((d) => d.id === dhikrId) || DHIKR_PRESETS[0];
  const progress = Math.min(1, count / target);

  async function onTap() {
    const { reachedTarget } = increment();
    if (!vibrate) return;
    if (reachedTarget) {
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } else {
      await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  }

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}>
        <Text style={styles.title}>المسبحة</Text>

        {/* اختيار الذكر */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.chips}
        >
          {DHIKR_PRESETS.map((d) => (
            <TouchableOpacity
              key={d.id}
              onPress={() => setDhikr(d.id)}
              style={[styles.chip, dhikrId === d.id && styles.chipActive]}
            >
              <Text style={[styles.chipTxt, dhikrId === d.id && styles.chipTxtActive]}>
                {d.text}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* الذكر الحالي */}
        <Text style={styles.dhikrBig}>{dhikr.text}</Text>

        {/* زر العدّ الكبير */}
        <Pressable onPress={onTap} style={({ pressed }) => [styles.bigBtn, pressed && styles.bigBtnPressed]}>
          <View style={styles.ring}>
            <View style={[styles.ringFill, { height: `${progress * 100}%` }]} />
            <View style={styles.ringCenter}>
              <Text style={styles.count}>{toArabicDigits(count)}</Text>
              <Text style={styles.ofTarget}>/ {toArabicDigits(target)}</Text>
            </View>
          </View>
          <Text style={styles.tapHint}>اضغط للتسبيح</Text>
        </Pressable>

        {/* الهدف */}
        <View style={styles.targetRow}>
          {TARGETS.map((t) => (
            <TouchableOpacity
              key={t}
              onPress={() => setTarget(t)}
              style={[styles.targetChip, target === t && styles.targetChipActive]}
            >
              <Text style={[styles.targetTxt, target === t && styles.targetTxtActive]}>
                {toArabicDigits(t)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* إحصائيات */}
        <View style={styles.stats}>
          <Stat label="الدورات" value={toArabicDigits(laps)} icon="repeat" />
          <Stat label="اليوم" value={toArabicDigits(todayTotal)} icon="today-outline" />
          <Stat label="الإجمالي" value={toArabicDigits(grandTotal)} icon="infinite-outline" />
        </View>

        <TouchableOpacity style={styles.resetBtn} onPress={reset} activeOpacity={0.8}>
          <Ionicons name="refresh" size={18} color={colors.textOnDark} />
          <Text style={styles.resetTxt}>تصفير العدّاد</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

function Stat({ label, value, icon }: { label: string; value: string; icon: any }) {
  return (
    <View style={styles.statBox}>
      <Ionicons name={icon} size={18} color={colors.goldSoft} />
      <Text style={styles.statVal}>{value}</Text>
      <Text style={styles.statLbl}>{label}</Text>
    </View>
  );
}

const RING = 240;
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  title: { fontFamily: fonts.bold, fontSize: 22, color: colors.goldSoft, textAlign: 'center', marginTop: 8 },

  chips: { paddingHorizontal: 12, gap: 8, paddingVertical: 14 },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.line,
  },
  chipActive: { backgroundColor: colors.gold, borderColor: colors.gold },
  chipTxt: { fontFamily: fonts.medium, fontSize: 15, color: colors.textOnDark },
  chipTxtActive: { color: colors.bgDeep },

  dhikrBig: {
    fontFamily: fonts.quranBold,
    fontSize: 30,
    color: colors.white,
    textAlign: 'center',
    marginTop: 4,
    marginBottom: 8,
  },

  bigBtn: { alignItems: 'center', marginTop: 10 },
  bigBtnPressed: { opacity: 0.9, transform: [{ scale: 0.98 }] },
  ring: {
    width: RING,
    height: RING,
    borderRadius: RING / 2,
    backgroundColor: colors.surface,
    borderWidth: 8,
    borderColor: colors.gold,
    overflow: 'hidden',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  ringFill: { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: '#D4AF3733' },
  ringCenter: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' },
  count: { fontFamily: fonts.bold, fontSize: 84, color: colors.white, lineHeight: 92 },
  ofTarget: { fontFamily: fonts.medium, fontSize: 20, color: colors.textMutedOnDark, marginTop: -6 },
  tapHint: { fontFamily: fonts.regular, fontSize: 13, color: colors.textMutedOnDark, marginTop: 12 },

  targetRow: { flexDirection: 'row-reverse', justifyContent: 'center', gap: 10, marginTop: 18 },
  targetChip: {
    width: 62,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: colors.surface,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.line,
  },
  targetChipActive: { backgroundColor: colors.teal, borderColor: colors.tealLight },
  targetTxt: { fontFamily: fonts.bold, fontSize: 16, color: colors.textOnDark },
  targetTxtActive: { color: colors.white },

  stats: { flexDirection: 'row-reverse', justifyContent: 'space-between', marginHorizontal: 16, marginTop: 22, gap: 10 },
  statBox: {
    flex: 1,
    backgroundColor: colors.surface,
    borderRadius: 16,
    paddingVertical: 14,
    alignItems: 'center',
    gap: 4,
    borderWidth: 1,
    borderColor: colors.line,
  },
  statVal: { fontFamily: fonts.bold, fontSize: 22, color: colors.white },
  statLbl: { fontFamily: fonts.regular, fontSize: 12, color: colors.textMutedOnDark },

  resetBtn: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginHorizontal: 16,
    marginTop: 20,
    paddingVertical: 12,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.line,
    backgroundColor: colors.surfaceAlt,
  },
  resetTxt: { fontFamily: fonts.medium, fontSize: 15, color: colors.textOnDark },
});
